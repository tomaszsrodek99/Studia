<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application - News';
?>

<div class="container">
    <h1>NEWS</h1>

    <div class="row">
        <div class="col-4 news_field"></div>
        <div class="col-4 news_field"></div>
        <div class="col-4 news_field"></div>
    </div>

    <div class="row">
        <div class="col-4 news_field"></div>
        <div class="col-4 news_field"></div>
        <div class="col-4 news_field"></div>
    </div>

    <div class="row">
        <div class="col-4 news_field"></div>
        <div class="col-4 news_field"></div>
        <div class="col-4 news_field"></div>
    </div>

</div>

$(document).ready(function () {
    // $('.third-button').on('click', function () {
    // 	$('.animated-icon3').toggleClass('open');
    // 	$('.header__menu').toggleClass('header__menu--open');
    // });
    $('.open').on('click', function () {
        $('.add_form').toggleClass('add_form--open');
    });
    $('.team_add').on('click', function () {
        $('.my_team_add').toggleClass('my_team_add--open');
        $('.team_add_hidden').toggleClass('NULL');
    });
    $('.team_delete').on('click', function () {
        $('.my_team_delete').toggleClass('my_team_delete--open');
        $('.delete_team_hidden').toggleClass('NULL');
    });
    $('.league_delete').on('click', function () {
        $('.my_league_delete').toggleClass('my_team_delete--open');
        $('.delete_league_hidden').toggleClass('NULL');
    });
});
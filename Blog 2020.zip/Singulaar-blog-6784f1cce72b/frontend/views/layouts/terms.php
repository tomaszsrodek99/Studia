<?php

/* @var $this View */

/* @var $content string */

use common\widgets\FooterWidget;
use common\widgets\TermsNavbarWidget;
use yii\helpers\Html;
use yii\web\View;
use frontend\assets\AppAsset;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php $this->registerCsrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
    <?php include('head.php'); ?>
</head>
<?php $this->beginBody() ?>
<div class="page">
    <?php TermsNavbarWidget::begin(); ?>
    <?php TermsNavbarWidget::end(); ?>
    <?= $content ?>
    <?php FooterWidget::begin(); ?>
    <?php FooterWidget::end(); ?>
</div>
<?php $this->endBody() ?>
</html>
<?php $this->endPage() ?>
